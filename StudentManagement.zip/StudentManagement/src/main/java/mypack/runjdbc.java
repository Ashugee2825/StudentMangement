package mypack;

public class runjdbc {

	public static void main(String[] args) {
		
		
		Jdbconnection jdb = new Jdbconnection();
		jdb.createDatabase();

	}

}
