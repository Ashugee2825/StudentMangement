package mypack;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class Jdbconnection {
	
	//load driver-->no need in new versions
	//establish connection
	//create conn
	//create statement(write query)
	//execute query
	//close connection
	public void createDatabase() {
		
	
	try {
		String url ="jdbc:mysql://localhost:3306/";
		String username = "root";
		String password ="123456789";
		
		Connection conn = DriverManager.getConnection(url,username,password);
		Statement stm = conn.createStatement();
		
		String query ="CREATE DATABASE dbservice";
		stm.execute(query);
		System.out.println("database created");
		
		conn.close();
		
	}catch(Exception e) {
		e.printStackTrace();
	}
	}
}
