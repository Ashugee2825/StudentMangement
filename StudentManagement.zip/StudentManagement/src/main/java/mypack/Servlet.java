package mypack;

public class Servlet {

}
