package practical;

public class Q19 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
