package practical;

import java.util.*;

public class Q3 {

	public static void main(String[] args) {
		// TO  FIND  SUM  ,  DIFFERENCE  ,  DIVISION  , MULTIPLICATION  ,  REMAINDER  OF  TWO  NUMBERS  BY   USER.
		Scanner sc = new Scanner(System.in);
		System.out.print("num1 =");
		int a = sc.nextInt();
		System.out.print("num2 =");
		int b = sc.nextInt();
		
		System.out.println("sum =" +(a+b));
		System.out.println("sub =" +(a-b));
		System.out.println("mul =" +(a*b));
		System.out.println("div =" +(a/b));
		System.out.println("rem =" +(a%b));


	}

}
