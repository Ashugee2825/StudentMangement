package practical;

import java.util.*;

public class Q6 {

	public static void main(String[] args) {
		//TO PRINT 4-DIGIT NUMBER.
		/*int a = 7;
		int b = 5;
		int c = 3;
		int d = 2;*/
		Scanner sc = new Scanner(System.in);
		int a = sc.nextInt();
		int b = sc.nextInt();
		int c = sc.nextInt();
		int d = sc.nextInt();
		int num = a*1000+b*100+c*10+d;
		System.out.println("num is =" +(num));
		
		
		

	}

}
