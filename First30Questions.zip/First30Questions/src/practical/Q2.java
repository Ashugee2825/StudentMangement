package practical;

public class Q2 {

	public static void main(String[] args) {
		// TO  FIND  SUM  ,  DIFFERENCE  ,  DIVISION  , MULTIPLICATION  ,  REMAINDER  OF   TWO  NUMBERS  BY   USING INTEGER.

		int a= 89;
		int b= 67;
		int sum =a+b;
		int sub =a-b;
		int mul =a*b;
		int div =a/b;
		int mod =a%b;
		System.out.println("sum ="+sum);
		System.out.println("sub ="+sub);
		System.out.println("mul ="+mul);
		System.out.println("div ="+div);
		System.out.println("mod ="+mod);
		


	}

}
