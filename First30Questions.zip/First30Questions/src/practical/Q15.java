package practical;

import java.util.*;

public class Q15 {

	public static void main(String[] args) {
		// TO  FIND  WHETHER  A  GIVEN  NUMBER  IS  EVEN  OR ODD.
		Scanner sc = new Scanner(System.in);
		int a=sc.nextInt();
		if(a%2==0) {
			System.out.print("even no is :" +""+a);
		}else {
			System.out.print("odd no is :" +"" +a);
		}


	}

}
