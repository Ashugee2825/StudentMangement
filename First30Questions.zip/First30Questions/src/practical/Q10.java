package practical;

public class Q10 {

	public static void main(String[] args) {
		// TO  PRINT 4-DIGIT NUMBER IN REVERSE ORDER.
		int a=5467;
		int b=a%10;
		System.out.print(b);
		int c=(a/10)%10;
		System.out.print(c);
		int d=(a/100)%10;
		System.out.print(d);
		int e=(a/1000)%10;
		System.out.print(e);
		

	}
	
}
