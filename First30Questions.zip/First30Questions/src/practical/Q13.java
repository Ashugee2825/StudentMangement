package practical;

public class Q13 {

	public static void main(String[] args) {
		// TO  FIND MAXIMUM   OF  THREE NUMBERS.
				int a = 356;
				int b=  55;
				int c=  4;
				if(a>b) {
					//System.out.println("greater no is:" +a);
					if(a>c) {
						System.out.println("greater no is:" +a);
					}else {
						System.out.println("greater no is:" +c);
					}
			
				}else {
					//System.out.println("greater no is:" +b);
					if(b>c) {
						System.out.println("greater no is:" +b);
					}else {
						System.out.println("greater no is:" +c);
					}
				}


	}

}
