package practical;

public class Q12 {

	public static void main(String[] args) {
		// TO  FIND MINIMUM   OF   TWO NUMBERS.
		
		int a = 675;
		int b= 65;
		if(a<b) {
			System.out.println("smaller no is:" +a);
			
		}else {
			System.out.println("smaller no is:" +b);
		}


	}

}
