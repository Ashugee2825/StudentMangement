package practical;

public class FirstQ {

	public static void main(String[] args) {
		// WELCOME TO THE WORLD OF PROGRAMMING 
		System.out.println("WELCOME TO THE WORLD OF PROGRAMMING ");

	}

}
