package practical;

public class Q8 {

	public static void main(String[] args) {
		// TO  EXCHANGE   TWO VARIABLES   WITHOUT   USING 3RD VARIABLE.
		int a= 3,b=4;
		
		System.out.println(b=a);


	}

}
