package practical;

import java.util.*;

public class Q17 {

	public static void main(String[] args) {
		//  FIND  MAXIMUM OF FOUR NUMBERS.
		Scanner sc= new Scanner(System.in);
		int v1=sc.nextInt();
		int v2=sc.nextInt();
		int v3=sc.nextInt();
		int v4=sc.nextInt();
		
		if(v1>v2) {
			
		}else if(v2>v1) {
			
		}
		

	}

}
