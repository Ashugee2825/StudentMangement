package practical;

public class Q9 {

	public static void main(String[] args) {
		// TO  PRINT SUM OF 4-DIGIT NUMBER .
		int a=4678;
		int b=a%10;
		System.out.println(b); 
		int c=(a/10)%10;
		System.out.println(c); 
		int d=(a/100)%10;
		System.out.println(d); 
		int e=(a/1000)%10;
		System.out.println(e); 
		System.out.println(b+c+d+e);

	}

}
