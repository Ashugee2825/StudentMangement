package practical;

public class Q5 {

	public static void main(String[] args) {
		//TO FIND SUM , DIFFERENCE ,DIVISION,MULTIPLICATION,REMAINDER OF TWO NUMBERS USING FLOAT AND INTEGER (MIX).
		int a = 675;
		float b = 78.4f;
		
		System.out.println("sum =" +(a+b));
		System.out.println("sub =" +(a-b));
		System.out.println("mul =" +(a*b));
		System.out.println("div =" +(a/b));
		System.out.println("rem =" +(a%b));
		


	}

}
