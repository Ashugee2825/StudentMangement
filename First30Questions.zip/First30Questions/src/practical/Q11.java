package practical;

public class Q11 {

	public static void main(String[] args) {
		// TO  FIND MAXIMUM   OF  TWO NUMBERS.
		int a = 56;
		int b= 65;
		if(a>b) {
			System.out.println("greater no is:" +a);
			
		}else {
			System.out.println("greater no is:" +b);
		}

	}

}
