package practical;

import java.util.*;

public class Q4 {

	public static void main(String[] args) {
		// TO  FIND  SUM  , DIFFERENCE  ,  DIVISION  , MULTIPLICATION   ,  REMAINDER  OF  TWO  NUMBERS  USING FLOAT.
		Scanner sc = new Scanner(System.in);
		System.out.print("num1 = ");
		float a = sc.nextFloat();
		System.out.print("num2 =");
		float b = sc.nextFloat();
		
		System.out.println("sum =" +(a+b));
		System.out.println("sub =" +(a-b));
		System.out.println("mul =" +(a*b));
		System.out.println("div =" +(a/b));
		System.out.println("rem =" +(a%b));

	}

}
