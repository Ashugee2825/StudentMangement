package practical;

public class Q14 {

	public static void main(String[] args) {
		// TO  FIND Minimum   OF  THREE NUMBERS.
		int a = 353566;
		int b=  545675;
		int c=  674;
		if(a<b) {
			//System.out.println("smaller no is:" +a);
			if(a<c) {
				System.out.println("smaller  no is:" +a);
			}else {
				System.out.println("smaller  no is:" +c);
			}
	
		}else {
			//System.out.println("smaller  no is:" +b);
			if(b<c) {
				System.out.println("smaller  no is:" +b);
			}else {
				System.out.println("smaller  no is:" +c);
			}
		}
	}

}
